
const MessengerForm = () => {
    return (
        <form className='messenger-form'>
            <input type='text' />
            <button>Send</button>
        </form>
    )
}

export default MessengerForm