import './Message.css'

const Message = () => {
    return (
        <div className="message">
            <img src="https://erazahan.info/wp-content/uploads/2016/09/Նկար-500x400.jpg" />
            <span>user_name</span>
            <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
            </p>
        </div>
    )
}
export default Message