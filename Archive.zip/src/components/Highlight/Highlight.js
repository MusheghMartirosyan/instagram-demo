import './Highlight.css'

const Highlight = () => {
    return (
        <div className="highlight"><img src="https://olay.az/uploads/posts/2022-09/1662660568_unknown_305865424_767158234560225_4789357751454008734_n.jpg" alt="Elizabet"/><span>Actual</span></div>
    )
}

export default Highlight